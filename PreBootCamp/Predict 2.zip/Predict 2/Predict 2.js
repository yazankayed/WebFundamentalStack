function displayContactInfo() {
    var auntContactInfo = ["Paula", "Smith", "1234 Main Street", "St. Louis", "MO", 12345];
    console.log(auntContactInfo);
}

  auntContactInfo =  ["Paula", "Smith", "1234 Main Street", "St. Louis", "MO", 12345]

  function displayGrocerylist() {
    var produce = ["apples", "oranges"];
    var frozen = ["broccoli", "ice cream"];
    frozen.push("hashbrowns");
    console.log(frozen);
}

produce = ["apples", "oranges"]


frozen = ["broccoli", "ice cream","frozen"]

var movieLibrary = ["Bambi", "E.T.", "Toy Story"];
movieLibrary.push("Zoro");
movieLibrary[1] = "Beetlejuice";
console.log(movieLibrary);


movieLibrary = ["Bambi","Beetlejuice", "Toy Story","Zoro"]



