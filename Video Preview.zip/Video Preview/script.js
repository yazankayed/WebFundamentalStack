function over(element)
{
    element.play()
}
function outerHeight(element)
{
    element.pause()
}