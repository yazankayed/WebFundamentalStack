let i = 4;

while (i >= -3.5 )
{

    console.log(i)


    i=i-1.5

}