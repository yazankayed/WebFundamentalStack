
let x=1;

for(let i=12; i!=0;i-- )
{

    x=x*i
}
console.log(x)