for(let i=3; i<100;i=i+3 )
{

    console.log(i)
}