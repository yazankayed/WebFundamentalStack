
let counterone=3;

var countone = document.querySelector("#likeOne");
console.log(countone)

function buttonOne()
{
++counterone
countone.innerText=  counterone+" Like(s)"
console.log (counterone)

}