
let counterone=9;

var countone = document.querySelector("#likeOne");
console.log(countone)

function buttonOne()
{
++counterone
countone.innerText=  counterone+" Like(s)"
console.log (counterone)

}





let countertwo=12;
var counttwo = document.querySelector("#likeTwo");
console.log(counttwo)

function buttonTwo()
{
++countertwo
counttwo.innerText=  countertwo+" Like(s)"
console.log (countertwo)

}



let counterthree=9;
var countthree = document.querySelector("#likeThree");
console.log(countthree)

function buttonThree()
{
++counterthree
countthree.innerText=  counterthree+" Like(s)"
console.log (counterthree)

}