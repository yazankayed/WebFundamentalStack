var doe = document.querySelector  ("#name")
console.log(doe)

function change()
{
doe.innerText = "Harvey Spectar" ;

}

var counterTwo =500;
var counter = 2;
var listDele = document.querySelector ("#list");
var count = document.querySelector  ("#req");
var element =document.querySelector  ("#connections");

function decline()
{
counter--

listDele.remove();

count.innerText = +counter;


}


function accept()
{
    counter--
counterTwo++

listDele.remove();

count.innerText = +counter;
element.innerText= +counterTwo


}


var listDelee = document.querySelector ("#listt");

function declinee()
{
counter--

listDelee.remove();

count.innerText = +counter;


}


function acceptt()
{
    counter--
counterTwo++

listDelee.remove();

count.innerText = +counter;
element.innerText= +counterTwo


}